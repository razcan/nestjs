import { HttpModule } from '@nestjs/common';
import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Employee } from './employee/employee.entity';
import { EmployeeModule } from './employee/employee.module';
import { EmployeeController } from './employee/employee.controller';
import { EmployeeService } from './employee/employee.service';
// import {EmployeeRepository} from './employee/employee.repository';

@Module({
  imports: [HttpModule,
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: '10.0.1.245',
      port: 3306,
      username: 'apiv4usr',
      password: 'Tinmar_2K21',
      database: 'apiv4',
      entities: [],
      synchronize: true,
      autoLoadEntities: true,
    }),
    EmployeeModule,
  ],
  // controllers: [AppController, EmployeeController],
  // providers: [AppService, EmployeeService],
})
export class AppModule {}