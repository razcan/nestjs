
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Employee } from './Employee.entity';
import { CreateEmployeeDto } from './dto/create-employee.dto';


@Injectable()
export class EmployeeService {
  constructor(
    @InjectRepository(Employee)
    private EmployeesRepository: Repository<Employee>,
  ) {}

  create(createEmployeeDto: CreateEmployeeDto): Promise<Employee> {
    const employee = new Employee();
    employee.firstName = createEmployeeDto.firstName;
    employee.lastName = createEmployeeDto.lastName;

    return this.EmployeesRepository.save(employee);
  }


  async findAll(): Promise<Employee[]> {
    return this.EmployeesRepository.find();
  }

  findOne(id: string): Promise<Employee> {
    return this.EmployeesRepository.findOne(id);
  }

  async remove(id: string): Promise<void> {
    await this.EmployeesRepository.delete(id);
  }
}